---
name: database-backup-restoration
description: "Use when restoring database backups (any SGBD) into Docker containers — format detection, decompression, SGBD identification, Docker lifecycle, deduplication, and Telegram notification of credentials."
version: 1.12.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [database, backup, restore, docker, sql-server, mysql, postgresql, telegram, deduplication]
    related_skills: [plan, systematic-debugging]
---

# Database Backup Restoration Pipeline

## Overview

Automates the full lifecycle of receiving a database backup file, identifying its
format (magic bytes, compression, SGBD), restoring it into an isolated Docker
container, and delivering access credentials to the user. Designed for async
operation — restores can take minutes to hours; the user gets progress updates
and a final notification instead of blocking.

## When to Use

- User sends/uploaded a database backup file (.bak, .sql, .csv, .dump, .bacpac)
- User asks to restore a backup from cloud storage (Google Drive, OneDrive, etc.)
- User asks to restore a backup into a Docker container
- You need to detect compressed/archived backup formats (.zip, .gz, .tar.gz, .rar, .7z)
- You need to identify which SGBD produced a .sql dump (MySQL vs SQL Server vs PostgreSQL)
- You need to notify the user (Telegram) when a long restore finishes

**Do NOT use for:** routine SQL queries, live database migrations, or backups
that are already mounted/accessible in the target database.

## Cloud Storage as Backup Source

When backup files live in cloud storage (Google Drive, OneDrive, Dropbox, etc.)
instead of being uploaded directly, use **rclone** to fetch them. rclone supports
40+ cloud providers with a single CLI tool and **does not require a Google Cloud
Platform project** — OAuth is handled directly in the terminal.

**When to use rclone vs Google Workspace API (gws):**

| | `google-workspace` skill (gws) | rclone |
|---|---|---|
| Requires GCP project | ✅ Yes | ❌ No |
| Requires `resourcemanager.projects.create` | ✅ Yes | ❌ No |
| List/search files | ✅ `drive search` | ✅ `rclone ls/lsf` |
| Download single file | ✅ `drive download` | ✅ `rclone copy` |
| Sync entire folder | ❌ Manual | ✅ `rclone sync` |
| Filter by extension | ❌ Query syntax | ✅ `--include "*.bak"` |
| Incremental/delta sync | ❌ No | ✅ `rclone check` |
| Other cloud providers | ❌ Google only | ✅ 40+ services |
| Setup time | ~10 min (burocrático) | ~2 min |

### Installing rclone (no sudo)

When `sudo apt install` fails (no password available), download the binary:

```bash
curl -sL -o /tmp/rclone.zip \
  "https://github.com/rclone/rclone/releases/download/v1.69.2/rclone-v1.69.2-linux-amd64.zip"
unzip -q /tmp/rclone.zip -d /tmp/rclone_extract
mkdir -p ~/bin
cp /tmp/rclone_extract/rclone-*/rclone ~/bin/
chmod +x ~/bin/rclone
export PATH="$HOME/bin:$PATH"
rclone version
```

### First-time Google Drive auth

```bash
rclone authorize "drive"
```

User opens the printed URL in their browser, authorizes, and the token is saved automatically.

### Common rclone commands for backup workflows

```bash
rclone ls drive:Backups-BD
rclone lsf drive:Backups-BD/MySQL
rclone copy drive:Backups-BD/MySQL/dump.sql.gz /home/hermes/backups/
rclone copy drive:Backups-BD /home/hermes/backups/ --include "*.{bak,sql,sql.gz}"
rclone sync drive:Backups-BD /home/hermes/backups/ --progress
rclone check drive:Backups-BD /home/hermes/backups/
```

### Listing files — prefer lsf over lsjson

`rclone lsf --format "stp" --separator "|"` returns size, modification time, and
path. It is faster and more reliable than `rclone lsjson`, which has been observed
to timeout on certain Google Drive folders where `lsf` works instantly.

| Command | Speed | Metadata | Reliability |
|---------|-------|----------|-------------|
| `lsf --format "stp"` | Fast | Size, ModTime, Path | Always works |
| `lsjson` | Slower | Full JSON (MimeType, ID, etc.) | Can timeout on GDrive |

Parse lsf output:
```python
r = subprocess.run(["rclone","lsf",path,"--format","stp","--separator","|"],
                   capture_output=True, text=True, timeout=30)
for linha in r.stdout.strip().split("\n"):
    tamanho_str, mod_time_str, nome = linha.split("|", 2)
    dt = datetime.strptime(mod_time_str, "%Y-%m-%d %H:%M:%S")
```

### Integration with restoration pipeline

After fetching files with rclone, feed them into the standard pipeline:
1. `rclone copy` → staging directory
2. Format detection (magic bytes, compression, SGBD)
3. Dedup check
4. Docker restore
5. Notification

### Watchdog / Auto-Restore Pattern (cron + lock)

For fully automated operation — place backups in a cloud folder and let the system
restore them one at a time — use a **watchdog script** driven by a cron job:

```
Cloud Folder (Backup/) →┬─ watchdog (cron every 15m)
                         │   1. List files in Backup/
                         │   2. Filter out already-processed
                         │   3. Acquire lock (file-based, TTL=2h)
                         │   4. Download first pending → SofiaBot restore
                         │   5. Move → Cloud Folder (Resultado/) with status prefix
                         └─ (lock prevents concurrent restores)
```

**Design decisions:**

| Concern | Solution |
|---------|----------|
| Concurrency | File lock with `fcntl.flock(LOCK_NB)` — one restore at a time |
| Stale lock | TTL check (2h) — lock older than TTL is force-released |
| Ordering | Sort pending files by name (proxy for FIFO) |
| Duplicate detection | SHA-256 via dedup registry + name check against Resultado/ |
| Post-processing | Move to Resultado/ with prefix: `sucesso_nome`, `falha_nome`, `ja_restaurado_nome` |
| Upload safety | Skip files with ModTime < 10min ago |
| Telegram notification | Sent on restore start (before download) + SofiaBot internal notifications |
| Error resilience | Failed operations logged but don't spam — script returns 0 |

**Critical path details:**
- The dedup registry (`registro_backups.db`) uses SHA-256 hash as primary key
- Lock file path: `/tmp/.sofia_watchdog.lock` with 2h TTL
- Files in `Resultado/` are skipped via name filter (fast pre-check before hash)

**Notification timing:** Send the Telegram notification BEFORE starting the
download, not after. Otherwise the user has no feedback during the download
phase (which can take minutes for large files):

```
Lock → Telegram notify → Download → Dedup check → SofiaBot restore → Move to Resultado/
```

**rclone copy timeout:** Default 300s may not be enough for 100MB+ files on slow
connections. Use 3600s (1h):

```python
subprocess.run(["rclone","copy",remote,local],
               capture_output=True, text=True, timeout=3600)
```

### Kanban-Based Watchdog (zero-token detection + worker isolation)

For token-optimized operation, use the **kanban trigger** approach instead of
a direct watchdog. The workflow:

```
Cloud Folder (Backup/) →┬─ sofia_kanban_watchdog.sh (cron 15min, no_agent=true, 0 tokens)
                         │   1. rclone lsf → list files in Backup/
                         │   2. python3 sqlite3 → filter already-processed (dedup registry)
                         │   3. For each new backup → hermes kanban create (with --skill flags)
                         │
                         └─ Kanban Board (dispatcher in gateway, ticks every 60s)
                              ├─ Task ready → assigned → running
                              └─ Worker agent (isolated session, ~30-50K tokens)
                                   ├─ Loads skills: sofia-cloud-restore-export + database-backup-restoration
                                   ├─ Downloads → restores → exports → uploads
                                   └─ kanban_complete()
```

**Why this beats a direct watchdog:**
- **Token efficiency:** detection script is `no_agent=true` (0 tokens). The worker
  runs in a fresh session (~30-50K tokens vs 330K+ in the main chat).
- **Parallelism:** multiple workers can run concurrently for different backups.
- **Retry:** the dispatcher re-queues failed tasks automatically.
- **Visibility:** `hermes kanban list` shows all pending/running/completed tasks.

**Setup:**

```bash
# Script lives in the project repo
cp /home/hermes/conversor-backups/scripts/sofia_kanban_watchdog.sh \
  ~/.hermes/scripts/sofia_kanban_watchdog.sh
chmod +x ~/.hermes/scripts/sofia_kanban_watchdog.sh

# Register cron — no_agent=true means script stdout = message, no LLM
cronjob action=create schedule="every 15m" name="Sofia Kanban Watchdog" \
  script=sofia_kanban_watchdog.sh no_agent=true deliver=telegram
```

**Script dependencies:** rclone, python3 (stdlib sqlite3), hermes CLI.
The script does NOT need the `sqlite3` CLI binary — it uses Python's stdlib
`sqlite3` module instead.

**Creating tasks manually:**
```bash
hermes kanban create \
  "Restaurar [sistema]cliente" \
  --body 'Descrição com passos...' \
  --skill sofia-cloud-restore-export \
  --skill database-backup-restoration \
  --max-runtime 2h

hermes kanban assign <task_id> default
```

### Cron setup — zero-token mode (no_agent=true)

Register the watchdog as a raw script cron to consume zero LLM tokens when idle:

```bash
# Create the wrapper script with .sh extension (required for bash in cron)
cat > ~/.hermes/scripts/sofia-watchdog.sh << 'WRAPPER'
#!/usr/bin/env bash
# Source .env for cron (docker-compose not involved)
ENV_FILE="/path/to/.env"
if [ -f "$ENV_FILE" ]; then set -a; source "$ENV_FILE"; set +a; fi
exec python3 /path/to/watchdog.py "$@"
WRAPPER
chmod +x ~/.hermes/scripts/sofia-watchdog.sh

# Register cron — no_agent=true means script stdout = message, no LLM
cronjob action=create schedule="every 15m" name="Sofia Watchdog GDrive" \
  script=sofia-watchdog.sh no_agent=true deliver=local
```

**Critical details:**
- **.sh extension is required** — the cron scheduler detects language by extension:
  `.sh`/`.bash` → bash, anything else → Python. A bash wrapper without `.sh` is
  parsed as Python and fails with `SyntaxError: Missing parentheses in call to 'exec'`.
- **Source .env explicitly** — cron does NOT auto-load `.env`. Without sourcing,
  `os.getenv("TELEGRAM_BOT_TOKEN")` returns empty and notifications silently fail.
- **Watchdog pattern:** script prints NOTHING when idle (no pending backups).
  Empty stdout = silent = no message delivered. Only print when a restore starts/completes.
- **Multiple instances hazard:** Starting a second watchdog while one is already
  running creates duplicate downloads. Check `process(action='list')` first, or use
  PID-file tracking with cleanup.

### config.py auto-load .env (project-level fix)

Python's `os.getenv()` reads real environment variables — `.env` is NOT sourced
automatically. When Sofia runs outside docker-compose (cron, CLI), all
`os.getenv()` calls return empty defaults.

**Fix — add to config.py at import time:**

```python
import os
from pathlib import Path

def _carregar_env():
    env_path = Path(__file__).resolve().parent.parent.parent / "sistemas_migrados" / ".env"
    if not env_path.is_file(): return
    with open(env_path) as f:
        for linha in f:
            linha = linha.strip()
            if not linha or linha.startswith("#") or "=" not in linha: continue
            chave, _, valor = linha.partition("=")
            chave = chave.strip(); valor = valor.strip().strip("\"'")
            if chave and not os.getenv(chave): os.environ[chave] = valor

_carregar_env()  # runs at module import
```

This ensures all `os.getenv()` calls (TELEGRAM_BOT_TOKEN, MYSQL_ROOT_PASSWORD,
SA_PASSWORD) work regardless of how the script is invoked.

## Architecture Pattern

```
 Cloud ─► rclone ─► staging/ ─► Format Detection ─► Decompress ─► Dedup Check ─► Docker Restore ─► Notify
                    │               │                  │               │               │
                    ▼               ▼                  ▼               ▼               ▼
              backup files     magic bytes +         .zip → .sql    SHA-256 hash    SQL Server /
                               extension              .gz → .sql     ↔ SQLite DB     MySQL /
                                                        .tar.gz → ...                PostgreSQL
```

## Format Detection Strategy

### 1. Magic bytes (never trust extension alone)

| Magic bytes | Format | Priority |
|-------------|--------|----------|
| `\x1f\x8b\x08` | GZIP | High |
| `\x50\x4b\x03\x04` | ZIP | High |
| `\x52\x61\x72\x21\x1a\x07` | RAR | High |
| `\x37\x7a\xbc\xaf\x27\x1c` | 7z | High |
| `\x42\x5a\x68` | BZIP2 | High |
| `\xfd37zxa\x00` | XZ | High |

.bak (SQL Server) has no universal magic — trust the extension but validate
via `RESTORE HEADERONLY`/`FILELISTONLY`.

### 2. Compression layer detection

When detected, extract to a temp dir and re-run detection on extracted files.
Support recursive extraction (nested archives). Use `gzip`, `zipfile`, `tarfile`
from stdlib, and `unrar`/`7z` CLI for RAR/7z.

### 3. SQL SGBD detection from content

For .sql files, score the first 500-5000 chars against known markers:

**SQL Server:** `GO`, `SET ANSI_NULLS`, `SET QUOTED_IDENTIFIER`,
`[dbo].`, `IDENTITY_INSERT`, `USE [` — each scores +1 to +2.

**MySQL:** `-- MySQL dump`, `/*!40101 SET`, `ENGINE=InnoDB`,
`LOCK TABLES`, `AUTO_INCREMENT`, backtick identifiers, `DEFINER=` — each scores +1 to +2.

**PostgreSQL:** `-- PostgreSQL database dump`, `SET statement_timeout`,
`COPY ... FROM stdin`, `SET client_encoding` — each scores +1 to +3.

Pick the highest total. If scores tie or all are 0, ask the user.

### 4. Unknown formats

When confidence < 0.5, notify the user with evidence and ask which SGBD
generated the backup. Do NOT proceed with a blind restore.

## Restoration Strategy per Format

| Detected Format | Primary SGBD (Docker) | Fallback | Notes |
|---|---|---|---|
| .bak | SQL Server | MySQL (as SQL dump) | Use `RESTORE FILELISTONLY` + `MOVE` clauses |
| .sql (T-SQL) | SQL Server | — | Use `sqlcmd -i` or batch by `GO` |
| .sql (MySQL) | MySQL | SQL Server | Use pipe: `mysql < file` (NOT `SOURCE` via `-e`!) |
| .sql (PostgreSQL) | PostgreSQL | — | Use `psql -f` |
| .csv | SQL Server (try first) | MySQL (fallback) | `pandas` + `sqlalchemy` + `pymysql` required. `restaurar_csv()` tries SQL Server via pyodbc first. On any exception (missing pyodbc/unixODBC, connection error), it catches and retries with MySQL via pymysql. Result reflects which SGBD actually served. Start mysql_migrados container first if stopped. |
| .bacpac | SQL Server | — | Via `SqlPackage` CLI |
| Compressed | Extract → redetect | — | Recurse to non-compressed format |

### Priority rule for .bak
Always try SQL Server `RESTORE DATABASE` first. Only fallback to another SGBD
if the RESTORE fails definitively (version incompatibility, corruption).

## Docker Container Lifecycle

### Fixed containers (from docker-compose.yml)
- `sqlserver_migrados` — SQL Server 2022 Developer
- `mysql_migrados` — MySQL 8.0
- `postgres_migrados` — PostgreSQL

### Prerequisite: .env file
Always verify `.env` exists before `docker compose up -d`. The `.env` is a
secret-bearing file — read via terminal tool, not `read_file`.

### Healthcheck pattern
```python
def garantir_sqlserver():
    1. Check `docker version` → abort if unavailable
    2. Check `docker inspect -f '{{.State.Running}}' sqlserver_migrados`
    3. If not running: `docker compose up -d sqlserver`
    4. Poll health every 5s for up to 120s
    5. Test TCP port (1433/3307/5432) via socket.create_connection
```

### File transfer into container
Use `docker cp` for small files. For large files (>1GB), pipe via stdin:
`docker exec -i container sh -c 'cat > /path' < local_file`

For compressed dumps, pipe directly into database CLI:
```bash
gunzip -c dump.sql.gz | docker exec -i mysql_migrados mysql -uroot -p'PASS' db
```

### Credentials pattern
Use **fixed credentials** per SGBD (read from `.env`), never generate random
passwords per job. This lets the user connect with known credentials across restores.

## Deduplication

SHA-256 of binary content (not filename) as the dedup key. Store in SQLite:

```sql
CREATE TABLE backups_importados (
    hash_arquivo   TEXT PRIMARY KEY,
    job_id         TEXT NOT NULL,
    nome_arquivo   TEXT NOT NULL,
    status         TEXT NOT NULL,  -- PENDENTE | EM_ANDAMENTO | CONCLUIDO | FALHA
    sgbd           TEXT,
    banco          TEXT,
    host           TEXT,
    porta          INTEGER,
    usuario        TEXT,
    concluido_em   TEXT
);
```

States:
- `CONCLUIDO` → skip restore, return stored credentials
- `EM_ANDAMENTO` → warn user, offer to wait
- `FALHA` → allow reprocess
- `PENDENTE` → process normally

## Job Isolation (Async Pattern)

Each backup gets:
1. A `job_id` (UUID hex, 32 chars)
2. An isolated staging directory (`staging/{job_id}/`)
3. A JSON job file (`jobs/{job_id}.json`) with full state
4. Docker containers are shared (fixed names), targets are unique per job

**Job states:** `PENDENTE → EM_ANALISE → AGUARDANDO_INFO | RESTAURANDO → CONCLUIDO | FALHA`

### Reset stuck registrations
When a restore fails mid-way, the dedup registry stays `EM_ANDAMENTO`. Reset it
to allow reprocessing:

```python
from registro_backups import RegistroBackups
reg = RegistroBackups()
for r in reg.listar():
    if r['status'] == 'EM_ANDAMENTO':
        reg.resetar(r['hash_arquivo'][:12])
```

## Telegram Notification

Use the Bot API via HTTP POST:

```
POST https://api.telegram.org/bot{TOKEN}/sendMessage
{"chat_id": "...", "text": "...", "parse_mode": "HTML"}
```

### Message templates

**Restore started (watchdog — sent before download):**
```
🔄 Nova restauração iniciada!
📦 Arquivo: <nome_arquivo>
📏 Tamanho: <size>MB

Baixando do Google Drive e preparando ambiente...
```

**Success (includes credentials):**
```
✅ Restauração concluída!
📦 Arquivo: <nome>
🗄️ SGBD: <SGBD>
🌐 Host: <host>:<porta>
🗂️ Banco: <nome_banco>
👤 Usuário: <user>
🔑 Senha: <pass>
⏱️ Tempo: <duração>
```

**Failure:**
```
❌ Restauração falhou
📦 Arquivo: <nome>
📋 Motivo: <mensagem>
```

## Common Pitfalls

1. **Extension lying.** A `.bak` may be a renamed tar/zip. Always check magic bytes first.

2. **Compression nesting.** `backup.tar.gz` may contain a `.zip` containing a `.sql`. Recurse until hitting a non-compressed format.

3. **SQL Server .bak path issues.** RESTORE runs inside the container — paths must be container-visible. Always `docker cp` first.

4. **GO separator confusion.** SQL Server dumps use `GO` as batch separator. Match with `^\s*GO(\s+\d+)?\s*;?\s*(--.*)?$`. Never split inside strings or `BEGIN/END` blocks.

5. **Nested format unwinding.** `formato_interno` must point to the deepest non-COMPOSTO format, not just the next layer. Walk the chain:
    ```python
    if isinstance(interno_result.formato_interno, FormatoBackup) and interno_result.formato_interno != FormatoBackup.COMPOSTO:
        resultado.formato_interno = interno_result.formato_interno
    ```

6. **temp_dir ownership.** Do NOT delete extracted temp dir in `finally` — store path in `resultado.temp_dir_extraido` and let the caller clean up after copying to staging.

7. **Staging file preference.** After extraction, prefer `.sql` > `.sql.gz` > `.bak`. Never restore `.gz` or `.tar` directly.

8. **Memory for large dumps.** Never read entire file into memory. Stream in 8MB blocks for decompression, hash, and copy.

9. **Deduplication by hash, not name.** Two files named `backup.bak` may differ. Hash binary content, not filename.

10. **Telegram token in logs.** Never log the bot token. Redact it in command strings.

11. **`atualizar_status()` requires status argument.** `JobManager.atualizar_status(self, job_id, status, **kwargs)` — the second positional argument `status` is NOT optional:
    ```python
    # WRONG — TypeError
    self.job_manager.atualizar_status(job_id, hash_arquivo=hash_arquivo)
    # RIGHT
    self.job_manager.atualizar_status(job_id, JEM_ANALISE, hash_arquivo=hash_arquivo)
    ```

12. **Cron script extension for no_agent mode.** Bash wrappers MUST have `.sh` extension:
    - `.sh`/`.bash` → bash
    - anything else → Python (parses as Python, fails with SyntaxError)

13. **Source .env in cron wrappers.** Cron does NOT load `.env`. Source it explicitly in the bash wrapper:
    ```bash
    if [ -f "$ENV_FILE" ]; then set -a; source "$ENV_FILE"; set +a; fi
    ```

14. **config.py auto-load .env for CLI/cron.** Add `_carregar_env()` at module import in config.py so `os.getenv()` works outside docker-compose.

15. **rclone copy timeout.** 300s may not be enough for 100MB+ files. Use 3600s.

16. **Notification timing.** Send Telegram notification BEFORE download, not after. User needs immediate feedback.

17. **Multiple watchdog instances.** Starting a second watchdog while one runs creates duplicate downloads. Use PID tracking or check `process(action='list')`.

18. **Upload cooldown for cloud-sourced backups.** Skip files with ModTime < 10 minutes old to avoid downloading partial uploads. Use `rclone lsf --format "stp"`:
    ```python
    dt = datetime.strptime(mod_time_str, "%Y-%m-%d %H:%M:%S")
    if time.time() - dt.timestamp() < 600: continue
    ```

19. **rclone auth port collision.** Port 53682 may be in use. Kill stale process or use `--port`. Check: `ss -tlnp 'sport = :53682'`.

20. **Missing runtime dependencies.** CSV batch import requires `pandas`, `sqlalchemy`, `pymysql`, `pyodbc`, and `psycopg2-binary`. On PEP 668 systems (Debian/Ubuntu 23.04+), create a virtualenv:
    ```bash
    cd /home/hermes/conversor-backups
    python3 -m venv venv
    source venv/bin/activate
    pip install pandas sqlalchemy pymysql pyodbc psycopg2-binary
    ```
    `numpy` (pandas dependency, 16.7 MB) is slow to download — allow 300s timeout.
    Always activate the venv before running Sofia: `source /home/hermes/conversor-backups/venv/bin/activate`.

21. **MySQL ERROR 1449 — DEFINER user does not exist.** Create the user before importing:
    ```bash
    mysql -uroot -p'PASS' -e "CREATE USER IF NOT EXISTS 'user'@'%' IDENTIFIED BY 'temp';"
    ```

22. **MySQL ERROR 1418 — log_bin_trust_function_creators.** Set before import:
    ```bash
    mysql -uroot -p'PASS' -e "SET GLOBAL log_bin_trust_function_creators=1;"
    ```

23. **Docker group not active in current shell.** Use `sg docker -c "command"` to execute with the docker group.

24. **Container port collision.** If a local MySQL is on the same port, stop it first before starting Docker.

26. **CSV fallback loop (SQL Server → MySQL).** `restaurar_csv()` defaults to `sgbd_destino="sqlserver"`. The method loops through `tentativas = ["sqlserver", "mysql"]`. If SQL Server raises any exception (ModuleNotFoundError for pyodbc, connection timeout, missing unixODBC), it catches, logs the error, and retries with MySQL. The caller's `sgbd_destino` is updated to `"mysql"` so the result metadata (host, port, user, password) reflects the actual SGBD used. If both fail, the last error is returned.

27. **MySQL container may be stopped.** `docker ps -a` shows `mysql_migrados` with `exited` status. Always check and start it before CSV imports:
    ```bash
    sg docker -c "docker start mysql_migrados" 2>&1
    ```
    This is common after VM restarts — Docker does not auto-start containers by default.

28. **`rclone cat` unreliable — use `rclone copy` for small files.** `rclone cat` can
    timeout even on tiny files (observed: 11-byte password file timed out at 10s).
    Prefer `rclone copy` to a local temp path and then read with `cat`:
    ```bash
    # UNRELIABLE — may timeout
    rclone cat "gdrive:path/to/senha.txt"
    # RELIABLE
    rclone copy "gdrive:path/to/senha.txt" /tmp/ && cat /tmp/senha.txt
    ```

29. **Password-protected archives — filename must be `senha.txt` (case-insensitive).**
    The Sofia code (`format_detector.py`, `_localizar_arquivo_senha()`) looks for
    exactly **`senha.txt`** — case-insensitive (`senha.txt`, `Senha.txt`, `SENHA.TXT`,
    etc.). Do NOT use `senha_bkp.txt`, `password.txt`, `senha` (sem extensão), or
    any other name — the detector will not find it.

    **Content format** — the file accepts two styles:
    - **Raw password** (single line, no prefix): `MinhaSenha123`
    - **Chave: valor** (case-insensitive key): `senha: MinhaSenha123`,
      `Senha = MinhaSenha123`, `password: MinhaSenha123`, `pwd: MinhaSenha123`
      (regex: `^\s*(senha|password|pwd)\s*[:=]\s*(.+?)\s*$`)

    **Manual extraction (outside Sofia):**
    1. Download the password file first: `rclone copy "remote:folder/senha.txt" /tmp/`
    2. Read the password: `PASSWORD=$(cat /tmp/senha.txt)`
    3. Extract with unrar: `unrar x -p"$PASSWORD" arquivo.rar`
    4. Proceed with format detection on extracted contents
    Never hardcode passwords — always read from the companion file.

    **Sofia CLI passthrough:** When invoking `sofia_bot.py` directly with `--senha`,
    ensure the password reaches `detectar_formato()` for individual files, not just
    `detectar_formato_pasta()` for folders. In `SofiaBot.processar_arquivo()`:
    ```python
    formato = (
        detectar_formato_pasta(arquivo_staging, senha_manual=senha_manual) if eh_pasta
        else detectar_formato(arquivo_staging, senha=senha_manual)  # ← must pass senha
    )
    ```
    Without the `senha=` kwarg on the file path, the CLI `--senha` flag is silently
    ignored and extraction fails — symptom: job status `AGUARDANDO_INFO` with
    message "não foi possível extrair/identificar o conteúdo interno."

30. **Compressed archive containing only CSVs → must redetect as CSV_LOTE.** When
    a `.rar`/`.zip`/`.7z` extracts to only `.csv` files (no `.sql`/`.bak`),
    `detectar_formato()` returns `COMPOSTO` with `formato_interno=CSV` and
    `sgbd=None`. The `SofiaBot` post-extraction block only reassigns
    `arquivo_staging` for `.sql`/`.sql.gz`/`.bak` — CSVs are ignored and the
    restore engine hits "Formato composto não pôde ser identificado após extração."

    **Fix (in `SofiaBot.processar_arquivo`, inside the `if formato.compactado` block):**
    ```python
    elif formato.formato_interno == FormatoBackup.CSV:
        # Remove the original archive from staging — only CSVs should remain,
        # otherwise detectar_formato_pasta rejects the mixed directory.
        rar_no_staging = staging_dir / nome_arquivo
        if rar_no_staging.is_file():
            rar_no_staging.unlink()
        # Redetect the staging dir as CSV_LOTE
        formato_lote = detectar_formato_pasta(str(staging_dir))
        if formato_lote.formato_primario == FormatoBackup.CSV_LOTE:
            formato = formato_lote
            arquivo_staging = str(staging_dir)
            eh_pasta = True
    ```
    Key detail: the original archive MUST be deleted from staging before calling
    `detectar_formato_pasta()` — that function rejects any directory where
    `len(csvs) != len(arquivos)`, so a `.rar` sitting alongside 30 `.csv` files
    triggers `DESCONHECIDO`.

## Project Git Workflow

When implementing new features, commit and push to GitHub automatically with
natural-language descriptions (Portuguese):

```bash
git add -A
git commit -m "✨ descrição concisa em português do que foi feito"
git push
```

**Conventions:**
- Prefix: `✨` (new), `🐛` (fix), `♻️` (refactor), `📝` (docs), `🔒` (security)
- Describe WHAT and WHY in plain Portuguese
- Include file paths and key details
- Push immediately (remote: SSH `git@github.com:<user>/<repo>.git`)

**SSH setup (one-time):**
```bash
ssh-keygen -t ed25519 -f ~/.ssh/id_ed25519 -N "" -C "hermes-watchdog"
cat ~/.ssh/id_ed25519.pub  # add at https://github.com/settings/keys
ssh-keyscan github.com >> ~/.ssh/known_hosts
git remote set-url origin git@github.com:<user>/<repo>.git
```

31. **Database name derived from staging directory → gets job_id, not filename.**  
    `RestoreEngine.restaurar()` derives `nome_banco` from `Path(caminho_arquivo).stem`.
    When a compressed archive is extracted and the format is `CSV_LOTE`, the
    `arquivo_staging` is the staging **directory** (e.g., `staging/dac2e13f.../`),
    so `.stem` returns the directory name (the `job_id`), not the original filename.
    Symptom: database named `dac2e13f3ab545ec9c6ae90ec36d7a9b` instead of
    `dados_magnus_csv`.

    **Fix:** Add optional `nome_banco_override` parameter to `restaurar()`.
    In `SofiaBot`, pass `nome_arquivo` (original filename) when `eh_pasta=True`:
    ```python
    # restore_engine.py — restaurar()
    def restaurar(self, caminho_arquivo, formato,
                  nome_banco_override: Optional[str] = None) -> ...:
        if nome_banco_override:
            nome_base = Path(nome_banco_override).stem.lower()
        else:
            nome_base = Path(caminho_arquivo).stem.lower()

    # sofia_bot.py — caller
    nome_banco_override = nome_arquivo if eh_pasta else None
    resultado = engine.restaurar(arquivo_staging, formato,
                                 nome_banco_override=nome_banco_override)
    ```

32. **`docker cp` timeout on large files (>1 GB) — use pipe instead.** The default
    `docker cp` with a 120s timeout fails on files ~10+ GB (observed: 12 GB SQL
    dump timed out during `copiar_para_container`). The `docker_manager.py`
    function must auto-detect file size and switch to pipe for files >1 GB:
    ```python
    # docker_manager.py
    PIPE_THRESHOLD_BYTES = 1_000_000_000  # 1 GB
    DOCKER_CP_TIMEOUT = 600  # 10 min

    def copiar_para_container(container, caminho_local, caminho_destino):
        local_path = Path(caminho_local)
        tamanho = local_path.stat().st_size if local_path.is_file() else 0

        if local_path.is_file() and tamanho > PIPE_THRESHOLD_BYTES:
            tamanho_mb = tamanho / (1024 * 1024)
            print(f"[DOCKER] Arquivo grande ({tamanho_mb:.0f} MB) — usando pipe em vez de docker cp...")
            with open(caminho_local, "rb") as f:
                subprocess.run(
                    ["docker", "exec", "-i", container, "sh", "-c",
                     f"cat > {caminho_destino}"],
                    stdin=f, check=True, capture_output=True, timeout=DOCKER_CP_TIMEOUT,
                )
            print("[DOCKER] Pipe concluído.")
        else:
            subprocess.run(
                ["docker", "cp", caminho_local, f"{container}:{caminho_destino}"],
                check=True, capture_output=True, text=True, timeout=DOCKER_CP_TIMEOUT,
            )
    ```
    **Symptom before fix:** `FALHA` with message "... timed out after 120 seconds".
    **Resolution:** after the fix, the Sofia process automatically detects the
    12 GB file and uses pipe, printing `[DOCKER] Arquivo grande (11931 MB) —
    usando pipe em vez de docker cp...`. The pipe is significantly faster than
    `docker cp` for multi-GB files because it avoids the tar-based copy overhead.

33. **PostgreSQL dump with `\connect` redirects to wrong database.** Some
    `pg_dump` outputs include `CREATE DATABASE <name>` followed by `\connect
    <name>`, which causes `psql` to switch databases mid-import. The Sofia
    creates the database from the filename (e.g., `teste_pg`), but the dump
    switches to a different database (e.g., `demo`). Result: the Sofia reports
    success for the wrong database (0 tables), while the actual data went
    elsewhere.

    **Symptom:** job `CONCLUIDO` with message "Importação PostgreSQL concluída
    com sucesso", but validation shows 0 tables in the Sofia-created database.
    The real database (from the dump's `\connect`) has the data.

    **Detection:** after PostgreSQL import, check for extra databases:
    ```bash
    docker exec postgres_migrados psql -U postgres -l
    docker exec postgres_migrados psql -U postgres -d <candidate> -c "\dt"
    ```
    **Future fix:** either strip `CREATE DATABASE`/`\connect` from the dump
    before import, or use `--no-owner --no-acl --clean` flags with `pg_restore`.

34. **Table-only filter can multiply file size 10× or more.** The
    `_filtrar_sql_tabelas()` function removes non-table objects but writes
    output as uncompressed SQL. A 998 MB `.sql.gz` dump can expand to 12 GB
    after filtering because: (a) gzip decompression, (b) write as plain SQL
    without recompression. Plan disk space accordingly — the staging directory
    must hold: original compressed file + extracted files + filtered file.
    Observed: 998 MB `.tar.gz` → 1 GB extracted + 1 GB companion file + 12 GB
    filtered = ~14 GB total staging.

35. **MySQL `SOURCE` via `-e` is a client command, not SQL — returns false
    negative.** The code `mysql ... -e "SOURCE /tmp/dump.sql"` appears to
    work (tables are created), but returns exit code 1 because `SOURCE` is a
    MySQL CLI command, not a SQL statement. The Sofia interprets exit code ≠ 0
    as failure and marks the job `FALHA` even though all data was imported
    successfully (confirmed: 1511 tables created, job marked FALHA).

    **Fix:** use shell pipe instead of `SOURCE`:
    ```python
    # WRONG — false negative
    executar_no_container(CONTAINER_MYSQL, [
        "mysql", "-uroot", f"-p{MYSQL_ROOT_PASSWORD}",
        nome_banco, "-e", f"SOURCE {caminho_container};",
    ])
    # RIGHT — reliable exit code
    executar_no_container(CONTAINER_MYSQL, [
        "sh", "-c",
        f"mysql -uroot -p{MYSQL_ROOT_PASSWORD} {nome_banco} < {caminho_container}",
    ])
    ```
    **After fix:** also update the job JSON and `registro_backups` for the affected
    job (the data is already there — just needs status corrected to CONCLUIDO).

36. **rclone copy preserves folder contents, not the folder name — `[sistema]` prefix lost.**  
    When copying a backup folder from Google Drive, the destination path
    determines the local folder name. If the remote is `[sophia]teste_2/` and
    the local target is `./staging/teste_2/`, the `[sistema]` prefix is lost.
    `identificar_sistema("teste_2")` cannot match it against the catalog, and
        the ActiveSoft export is silently skipped — the restore succeeds but no
        CSVs are generated.

        **Symptom:** job `CONCLUIDO` with no export block in the notification, no
        `Exportacao/` folder on Drive.

        **Fix — create the destination subfolder explicitly before copying:**
        ```bash
        # WRONG — copies contents directly into pendentes/
        rclone copy "gdrive:Backup/[sophia]teste_2" ./staging/pendentes/
        # RIGHT — create subfolder first, then copy into it
        mkdir -p "./staging/pendentes/[sophia]teste_2"
        rclone copy "gdrive:Backup/[sophia]teste_2" "./staging/pendentes/[sophia]teste_2/"
        ```
        This creates `./staging/pendentes/[sophia]teste_2/` with the correct name
        and the export engine can identify the system.

        **Manual recovery (files already downloaded without prefix):** if the
        files were already copied into `./staging/pendentes/` without the folder
        name, move them into a correctly-named subfolder:
        ```bash
        mkdir -p "./staging/pendentes/[sophia]teste_2"
        mv ./staging/pendentes/*.csv "./staging/pendentes/[sophia]teste_2/"
        ```
        Then re-run the Sofia bot pointing to the new subfolder.

        **If the export was already skipped**, re-run it directly via the export
        engine CLI (uses the same credentials and Drive target):
    ```bash
    cd <projeto> && PYTHONPATH=<projeto> \
      python3 -m sofia.core.export_engine <sistema> <cliente> \
      --banco <nome_banco> --sgbd <sqlserver|mysql> --upload
    ```
    This is the same path `sofia_bot.py` takes internally in
    `_exportar_activesoft()` — the export is idempotent and replaces any
    existing CSVs on Drive.

37. **Kanban tasks without `--assignee` stay in `ready` forever.**  
    The dispatcher (running in the gateway) only picks up tasks that have an
    `assignee` set. A task created with `hermes kanban create` without
    `--assignee default` shows `(unassigned)` in `hermes kanban list` and
    never advances to `running`.

    **Symptom:**
    ```
    hermes kanban list
    # ▶ t_abc123  ready     (unassigned)  Restaurar [sophia]cliente
    ```

    **Fix:** assign the task to a profile, then force a dispatch cycle:
    ```bash
    hermes kanban assign t_abc123 default
    hermes kanban dispatch   # força ciclo imediato, sem esperar 60s
    ```

    **Prevention:** always include `--assignee default` when creating tasks:
    ```bash
    hermes kanban create "Restaurar [sophia]cliente" \
      --assignee default \
      --skill sofia-cloud-restore-export \
      --skill database-backup-restoration \
      --max-runtime 2h
    ```

38. **Dedup says CONCLUIDO but database was deleted from container.**  
    The dedup registry (`registro_backups.db`) tracks SHA-256 hashes with
    status `CONCLUIDO`. When the Sofia bot finds a matching hash, it skips
    the restore entirely and returns the stored credentials. However, if the
    Docker container was recreated or the database was manually dropped, the
    database no longer exists even though the dedup says it was imported.

    **Symptom:** Sofia bot says "Este backup já foi importado anteriormente."
    but connecting with the returned credentials fails — the database is not
    found in `sys.databases` (SQL Server) or `SHOW DATABASES` (MySQL).

    **Fix — reset the dedup entry to PENDENTE and re-import:**
    ```bash
    cd /home/hermes/conversor-backups
    python3 -c "
    import sqlite3
    db = sqlite3.connect('sistemas_migrados/registro_backups.db')
    hash_alvo = '80be6241...'  # first 8+ chars of the hash from job output
    db.execute('UPDATE backups_importados SET status = ? WHERE hash_arquivo LIKE ?',
               ('PENDENTE', f'{hash_alvo}%'))
    db.commit()
    print(f'Entry {hash_alvo} reset to PENDENTE')
    "
    ```
    Then re-run the Sofia bot — it will re-import the backup.

    **Verification (before resetting):** confirm the database is really gone:
    ```sql
    -- SQL Server
    SELECT name FROM sys.databases WHERE name = '<nome_banco>';
    -- MySQL
    SHOW DATABASES LIKE '<nome_banco>';
    ```

    **Prevention:** after every container restart, check the dedup registry\n    against actual databases. A watchdog script that validates existing\n    databases on startup prevents this mismatch.\n\n39. **ODBC Driver version — check which driver is installed.**  \n    The connection string in `restaurar_csv()` hardcodes a specific ODBC driver.\n    Verify the installed driver before running:\n    ```bash\n    odbcinst -q -d\n    ```\n    Typical output on newer systems: `[ODBC Driver 18 for SQL Server]`.\n    If only Driver 17 is installed, the connection string must be updated.\n    Mismatch produces: `pyodbc.Error: Can't open lib 'ODBC Driver 18 for SQL Server'`.\n\n40. **CSV encoding + delimiter detection can fail on non-standard CSVs.**  \n    The `restaurar_csv()` method tries encodings in order:\n    `[\"utf-8\", \"utf-8-sig\", \"cp1252\", \"latin-1\"]` with `sep=None, engine=\"python\"`.\n    This fails when the CSV uses `;` as delimiter (common in Brazilian/latin systems)\n    or has unescaped quotes/quoted semicolons that confuse pandas' auto-detect.\n\n    **Symptom:** Job `FALHA` with message:\n    `\"Não foi possível ler o CSV com os encodings testados.\"`\n    The database is left partially imported — all tables before the failing CSV\n    have data, the failing CSV and any subsequent ones are empty/missing.\n\n    **Diagnosis:**\n    ```bash\n    python3 -c \"import pandas as pd\n    for enc in ['utf-8', 'latin1', 'cp1252', 'iso-8859-1']:\n        try:\n            df = pd.read_csv('arquivo.csv', encoding=enc, nrows=5)\n            print(f'OK: {enc}, cols={list(df.columns)}')\n            break\n        except Exception as e:\n            print(f'{enc}: {e}')\n    \"\n    head -3 arquivo.csv | cat -v\n    ```\n    Look for `;` as separator and `^M` (Windows line endings).\n\n41. **CSV_LOTE one-failure-stops-all design.**  \n    `restaurar_csv_lote()` iterates CSVs alphabetically and returns the first\n    error immediately. All CSVs before the failing one are committed (each\n    `to_sql` auto-commits with `if_exists=\"replace\"`). The failing CSV and\n    all subsequent CSVs are NOT imported. The job is `FALHA` even though\n    partial data exists in the database.\n\n    **Verification (use 3-part naming — `USE [db]` may fail if database is in transition):**\n    ```python\n    cursor.execute(\"SELECT TABLE_NAME FROM [db].INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE='BASE TABLE'\")\n    cursor.execute(\"SELECT COUNT(*) FROM [db].sys.objects WHERE type='U'\")\n    ```\n\n42. **Prefer `venv` over `--break-system-packages` for PEP 668.**  \n    System Python 3.11+ on Debian/Ubuntu blocks global `pip install`.\n    Always create a project-level venv and install all deps:\n    ```bash\n    cd /home/hermes/conversor-backups\n    python3 -m venv venv\n    source venv/bin/activate\n    pip install pandas sqlalchemy pymysql pyodbc psycopg2-binary\n    ```\n    `psycopg2-binary` is needed even for SQL Server-only restores because\n    `postgres_dump_dir.py` imports it unconditionally at module load time.\n\n## Parallel Restore Workflow

When multiple backups need restoration, use this pattern to maximize throughput:

### Phase 1: Download all files in parallel
```bash
# Start downloads simultaneously as background processes
rclone copy "remote:backup1.tar.gz" staging/pendentes/ &  # PID1
rclone copy "remote:backup2.sql"    staging/pendentes/ &  # PID2
rclone copy "remote:backup3.rar"    staging/pendentes/ &  # PID3
```

### Phase 2: Start restorations as downloads complete
Don't wait for all downloads — start restoring files the moment they land:
```python
delegate_task(
    goal="Restaurar backup1.tar.gz via Sofia bot...",
    context="Projeto em /home/hermes/conversor-backups. Comando: ..."
)
```

### Phase 3: Heavy files last (solo)
Large files (>500MB) should run alone to avoid RAM pressure from
simultaneous decompression + restore + container overhead. Check VM
resources first: `free -h`, `nproc`, `df -h`.

### Resource estimation for parallel runs
| Check | Command | Threshold for 3 parallel jobs |
|-------|---------|------|
| CPU | `nproc` | ≥5 cores |
| RAM free | `free -h` | ≥3 GB above current usage |
| Disk free | `df -h /` | ≥10 GB above temp space needed |
| Containers healthy | `docker ps` | All target SGBDs Up |

If RAM is tight (<3 GB headroom), run the 2 lightest in parallel and
the heavy one solo.

- [ ] Magic bytes checked before extension
- [ ] Compression detected and recursively extracted
- [ ] SGBD identified with confidence > 0.5
- [ ] Dedup hash from binary content
- [ ] Docker container healthy before restore
- [ ] max_allowed_packet set to 1G for MySQL
- [ ] Progress monitored every 30s during large imports
- [ ] Container port free
- [ ] `.env` exists with credentials
- [ ] Telegram notification sent
- [ ] Staging cleaned after conclusion
- [ ] Job JSON saved for audit trail
- [ ] MySQL: using pipe (`mysql < file`), not `SOURCE` via `-e` (false negative)
- [ ] PostgreSQL: checked for `\connect` redirect (dump may have created a different DB)
- [ ] Disk space: staging can hold compressed + extracted + filtered (filter may be 10× larger)
- [ ] Large files (>1 GB): using pipe in `copiar_para_container`, not `docker cp`
- [ ] `[sistema]` prefix preserved in local folder name after rclone download
- [ ] ActiveSoft export not silently skipped — verify export block in notification or re-run manually
- [ ] Database name: not using job_id when source is a directory (use `nome_banco_override`)
- [ ] Dedup CONCLUIDO: database actually exists in the container (query sys.databases / SHOW DATABASES)

## References

- `references/restore-commands.md` — SGBD-specific commands and magic bytes
- `references/mysql-static-binary-deployment.md` — MySQL 8.0 without Docker
- `references/tar-magic-detection.md` — TAR has no magic bytes, use `tarfile.is_tarfile()`
- `references/async-delegation.md` — Delegating long restores to subagents
- `references/offline-package-install.md` — Installing packages without sudo
- `references/cleanup-non-table-objects.md` — Post-import cleanup of views/functions/procedures
- `references/rclone-cloud-storage-setup.md` — rclone + Google Drive setup
- `references/watchdog-gdrive-architecture.md` — Watchdog architecture, constants, dependencies, and flow
- `references/parallel-restore-workflow.md` — Multi-backup parallel download + restore pattern with VM resource estimation
- `references/docker-cp-timeout-pipe-fix.md` — docker cp 120s timeout on large files → pipe-based fix in docker_manager.py
- `references/remote-client-connection.md` — DBeaver / remote client connection guide (IP, ports, driver settings, troubleshooting)
- `references/token-consumption-benchmarks.md` — Token consumption benchmarks for Hermes agent orchestrating restore workflows
- `references/kanban-trigger.md` — Kanban trigger integration for backup restore workflow\n- `references/csv-import-troubleshooting.md` — CSV encoding/delimiter failures and workarounds\n- `scripts/watchdog-gdrive.py` — Reference: watchdog cron script for auto-restore
- `scripts/sofia_kanban_watchdog.sh` — Kanban bridge: detects backups on Drive and creates kanban tasks