---
name: sofia-cloud-restore-export
description: "Restaura backups do Google Drive via Sofia + exportação ActiveSoft + upload dos CSVs de volta ao Drive. Fluxo completo: rclone download → Sofia restore → export_engine → rclone upload."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [sofia, restore, export, active-soft, google-drive, rclone, sql-server, mysql, csv]
    related_skills: [database-backup-restoration]
---

# Sofia Cloud Restore + Export

## Objetivo

Fluxo completo para restaurar um backup que está no Google Drive, executar a
exportação ActiveSoft, e subir os CSVs gerados de volta ao Drive na pasta de
exportação separada por cliente.

## Pré-requisitos

- Containers Docker rodando: `sqlserver_migrados`, `mysql_migrados`
- rclone configurado com remoto `gdrive:`
- PYTHONPATH apontando para o projeto:
  ```bash
  export PYTHONPATH=/home/hermes/conversor-backups
  ```

## Fluxo completo

### Passo 1 — Listar backups disponíveis

```bash
rclone lsf "gdrive:1.Profissional/Sofia/Backup/" --format "stp" --separator "|"
```

O nome da pasta/código segue o padrão `[sistema]cliente` (ex.: `[sophia]teste_2`).
Sistema e cliente são extraídos desse padrão pela função `identificar_sistema()`
do `export_engine.py`.

### Passo 2 — Baixar do Google Drive

```bash
mkdir -p /home/hermes/conversor-backups/staging/pendentes
rclone copy "gdrive:1.Profissional/Sofia/Backup/[sistema]cliente" \
  /home/hermes/conversor-backups/staging/pendentes/cliente/ --progress
```

**Timeout:** rclone copy padrão é 300s. Para arquivos grandes, usar 3600s.

### Passo 3 — Restaurar via Sofia bot

O Sofia bot detecta o formato (CSV_LOTE, .sql, .bak, etc.), restaura no container
Docker apropriado e tenta rodar a exportação ActiveSoft automaticamente.

```bash
cd /home/hermes/conversor-backups
PYTHONPATH=/home/hermes/conversor-backups python3 sofia/sofia_bot.py \
  /home/hermes/conversor-backups/staging/pendentes/cliente/
```

**Tempo:** de segundos (CSVs pequenos) a horas (dumps SQL grandes).
Para backups grandes, rodar em background:

```bash
cd /home/hermes/conversor-backups
PYTHONPATH=/home/hermes/conversor-backups python3 sofia/sofia_bot.py \
  /home/hermes/conversor-backups/staging/pendentes/cliente/ &
```

### Passo 4 — Verificar se a exportação rodou

O Sofia bot tenta identificar o sistema pelo nome do arquivo. Se a exportação
foi pulada (nome da pasta local não contém `[sistema]`), o log mostrará apenas
a restauração, sem as linhas `[EXPORT ]`.

**Sintoma de exportação pulada:** job termina CONCLUIDO mas sem menção a CSVs
de exportação no output.

Nesse caso, rodar a exportação manualmente:

```bash
cd /home/hermes/conversor-backups
PYTHONPATH=/home/hermes/conversor-backups python3 -m sofia.core.export_engine \
  <sistema> <cliente> --banco <nome_banco> --sgbd <sqlserver|mysql> --upload
```

Parâmetros:
- `sistema`: nome da pasta em `sofia/sistemas/` (ex.: `sophia`, `gestao_online`)
- `cliente`: segundo segmento do nome (ex.: `teste_2`)
- `--banco`: nome do banco restaurado (geralmente igual ao cliente)
- `--sgbd`: `sqlserver` ou `mysql` (padrão: `mysql`)
- `--upload`: sobe os CSVs para o Google Drive

### Passo 5 — Verificar resultado no Drive

```bash
rclone lsf "gdrive:1.Profissional/Sofia/Exportacao/<cliente>/" \
  --format "stp" --separator "|" -R
```

Os arquivos vão para:
`gdrive:1.Profissional/Sofia/Exportacao/<cliente>/exportacao_<sistema>_<cliente>/`

Conteúdo da pasta:
- `aluno.csv`, `matricula.csv`, `professor.csv`, `responsavel2.csv` (ou
  equivalentes do sistema)
- `relatorio_exportacao.txt` (relatório de validação e qualidade)

### Passo 6 — Credenciais de acesso ao banco

Após a restauração, o banco fica acessível com as credenciais fixas:

| SGBD | Host | Porta | Usuário | Senha |
|------|------|-------|---------|-------|
| SQL Server | localhost | 1433 | sa | (do .env) |
| MySQL | localhost | 3307 | root | (do .env) |

## Troubleshooting

### ModuleNotFoundError: No module named 'sofia'

```bash
export PYTHONPATH=/home/hermes/conversor-backups
```

### Docker não acessível

```bash
sg docker -c "docker ps"
```

### Container parado

```bash
sg docker -c "docker start mysql_migrados sqlserver_migrados"
```

### rclone não encontrado

```bash
export PATH="$HOME/bin:$PATH"
```

### Exportação pulada (sistema não identificado)

O `identificar_sistema()` espera o padrão `[sistema]cliente` no nome do arquivo.
Se a pasta local não tem os colchetes (ex.: baixou como `teste_2` em vez de
`[sophia]teste_2`), a exportação é pulada silenciosamente. Rodar o passo 4
manualmente resolve.

### Senha do SQL Server ou MySQL

As senhas estão no `.env` do projeto. O Sofia bot e o export_engine carregam
de lá automaticamente. Para acesso manual:

```bash
grep -E '^(SA_PASSWORD|MYSQL_ROOT_PASSWORD)=' /home/hermes/conversor-backups/sistemas_migrados/.env
```

## Exemplo completo

Restaurar backup `[sophia]magnus`:

```bash
# 1. Baixar
rclone copy "gdrive:1.Profissional/Sofia/Backup/[sophia]magnus" \
  /home/hermes/conversor-backups/staging/pendentes/magnus/ --progress

# 2. Restaurar + exportar
cd /home/hermes/conversor-backups
PYTHONPATH=/home/hermes/conversor-backups python3 sofia/sofia_bot.py \
  /home/hermes/conversor-backups/staging/pendentes/magnus/

# 3. Se exportação foi pulada, rodar manual:
PYTHONPATH=/home/hermes/conversor-backups python3 -m sofia.core.export_engine \
  sophia magnus --banco magnus --sgbd sqlserver --upload

# 4. Verificar
rclone lsf "gdrive:1.Profissional/Sofia/Exportacao/magnus/" \
  --format "stp" --separator "|" -R
```